import os
import re

# Gemini AI 3 Pro (Free 1year trial for University Students) Generated on 13th December, 2025

def batch_process_html_files():
    # 1. Configuration
    target_extension = ".html"
    
    # Config for Logo Replacement
    new_image_name = "BRAC.LOGO.jpg"
    
    # Config for CSS Replacement
    # WARNING: You wrote "sheey.css" in your prompt. 
    # If you meant "sheet.css", change the line below.
    replacement_css = "./../resources/sheey.css"

    # 2. Define the Regex Patterns
    
    # --- Pattern 1: Image Logos ---
    # Breakdown:
    # (src=['"])          -> Group 1: Matches src=' or src="
    # resources\/         -> Matches the literal folder 'resources/'
    # (image_[\d_]+\.jpg) -> Group 2: Matches the variable filenames (e.g., image_123_0.jpg)
    # (['"])              -> Group 3: Matches the closing quote ' or "
    pattern = re.compile(r"(src=['\"]resources\/)(image_[\d_]+\.jpg)(['\"])", re.IGNORECASE)

    # --- Pattern 2: CSS Links ---
    # Matches href="resources/sheet.css" or href='resources/sheet.css'
    pattern2 = re.compile(r"(href=['\"])resources\/sheet\.css(['\"])", re.IGNORECASE)

    # 3. Iterate over files
    current_directory = os.getcwd() + "/routines/"
    files_processed = 0
    files_modified = 0

    print(f"Scanning folder: {current_directory}...\n")

    for filename in os.listdir(current_directory):
        if filename.endswith(target_extension):
            files_processed += 1
            file_path = os.path.join(current_directory, filename)

            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()

                # --- Apply Pattern 1 (Logos) ---
                # We replace Group 2 (the old image filename) with new_image_name
                content_after_p1, count1 = pattern.subn(r'\g<1>' + new_image_name + r'\g<3>', content)

                # --- Apply Pattern 2 (CSS) ---
                # We replace the literal "resources/sheet.css" with the replacement_css variable
                # We keep Group 1 (href=") and Group 2 (closing ")
                final_content, count2 = pattern2.subn(r'\g<1>' + replacement_css + r'\g<2>', content_after_p1)

                # Write back if ANY changes happened
                if count1 > 0 or count2 > 0:
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(final_content)
                    
                    changes = []
                    if count1 > 0: changes.append(f"{count1} logo(s)")
                    if count2 > 0: changes.append(f"{count2} css link(s)")
                    
                    print(f"✅ [Fixed] {filename} - Updated: {', '.join(changes)}")
                    files_modified += 1

            except Exception as e:
                print(f"❌ [Error] Could not process {filename}: {e}")

    print("-" * 30)
    print(f"Summary: Scanned {files_processed} HTML files. Modified {files_modified} files.")

if __name__ == "__main__":
    batch_process_html_files()